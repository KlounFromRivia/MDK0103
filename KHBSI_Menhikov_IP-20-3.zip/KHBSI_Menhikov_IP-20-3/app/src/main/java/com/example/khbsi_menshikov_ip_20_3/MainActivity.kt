 package com.example.khbsi_menshikov_ip_20_3

import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.Window
import com.example.khbsi_menshikov_ip_20_3.databinding.ActivityMainBinding

 class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    lateinit var mainHandler : Handler
    private var Player: Int = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)


        //this.requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(binding.root)

        binding.btnGame.isEnabled = true
        btnEnabled(false)
        mainHandler = Handler(Looper.getMainLooper())
    }

     private fun btnEnabled(Enadle: Boolean){
         if (Enadle == true)
         {
             binding.btnRock.setBackgroundColor(Color.argb(255, 103, 58, 183))
             binding.btnIshir.setBackgroundColor(Color.argb(255, 103, 58, 183))
             binding.btnSpok.setBackgroundColor(Color.argb(255, 103, 58, 183))
             binding.btnHog.setBackgroundColor(Color.argb(255, 103, 58, 183))
             binding.btnPaper.setBackgroundColor(Color.argb(255, 103, 58, 183))
         }
         else
         {
             binding.btnRock.setBackgroundColor(Color.GRAY)
             binding.btnIshir.setBackgroundColor(Color.GRAY)
             binding.btnSpok.setBackgroundColor(Color.GRAY)
             binding.btnHog.setBackgroundColor(Color.GRAY)
             binding.btnPaper.setBackgroundColor(Color.GRAY)
         }
         binding.btnRock.isEnabled = Enadle
         binding.btnIshir.isEnabled = Enadle
         binding.btnSpok.isEnabled = Enadle
         binding.btnHog.isEnabled = Enadle
         binding.btnPaper.isEnabled = Enadle
     }

     private fun Bot():Int = (1..5).random() //Компьютер выбрал предмет

     fun btnPlayer(view: View)
     {
         binding.btnGame.isEnabled = true
         binding.btnGame.setBackgroundColor(Color.argb(255, 103, 58, 183))
         btnEnabled(false)

         when(view.getTag()){
             "Rock" -> { binding.btnRock.setBackgroundColor(Color.argb(255, 103, 58, 183))
                 when (Bot()) {
                     1 -> {
                         binding.txtGame.text = "Противник выбрал Камень\nНичья!"
                         binding.txtGame.setBackgroundColor(Color.YELLOW)
                     }
                     2 -> {
                         binding.txtGame.text = "Противник выбрал Ножницы\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                     3 -> {
                         binding.txtGame.text = "Противник выбрал Бумага\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                     4 -> {
                         binding.txtGame.text = "Противник выбрал Ящерица\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                     5 -> {
                         binding.txtGame.text = "Противник выбрал Спок\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                 }
             }
             "Ishir" -> {
                 binding.btnIshir.setBackgroundColor(Color.argb(255, 103, 58, 183))
                 when (Bot()) {
                     1 -> {
                         binding.txtGame.text = "Противник выбрал Камень\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                     2 -> {
                         binding.txtGame.text = "Противник выбрал Ножницы\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                     3 -> {
                         binding.txtGame.text = "Противник выбрал Бумага\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                     4 -> {
                         binding.txtGame.text = "Противник выбрал Ящерица\nНичья!"
                         binding.txtGame.setBackgroundColor(Color.YELLOW)
                     }
                     5 -> {
                         binding.txtGame.text = "Противник выбрал Спок\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                 }
             }
             "Paper" -> {
                 binding.btnPaper.setBackgroundColor(Color.argb(255, 103, 58, 183))
                 when (Bot()) {
                     1 -> {
                         binding.txtGame.text = "Противник выбрал Камень\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                     2 -> {
                         binding.txtGame.text = "Противник выбрал Ножницы\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                     3 -> {
                         binding.txtGame.text = "Противник выбрал Бумага\nНичья!"
                         binding.txtGame.setBackgroundColor(Color.YELLOW)
                     }
                     4 -> {
                         binding.txtGame.text = "Противник выбрал Ящерица\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                     5 -> {
                         binding.txtGame.text = "Противник выбрал Спок\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                 }
             }
             "Hog" -> {
                 binding.btnHog.setBackgroundColor(Color.argb(255, 103, 58, 183))
                 when (Bot()) {
                     1 -> {
                         binding.txtGame.text = "Противник выбрал Камень\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                     2 -> {
                         binding.txtGame.text = "Противник выбрал Ножницы\nНичья!"
                         binding.txtGame.setBackgroundColor(Color.YELLOW)
                     }
                     3 -> {
                         binding.txtGame.text = "Противник выбрал Бумага\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                     4 -> {
                         binding.txtGame.text = "Противник выбрал Ящерица\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                     5 -> {
                         binding.txtGame.text = "Противник выбрал Спок\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                 }
             }
             "Spok" -> {
                 binding.btnSpok.setBackgroundColor(Color.argb(255, 103, 58, 183))
                 when (Bot()) {
                     1 -> {
                         binding.txtGame.text = "Противник выбрал Камень\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                     2 -> {
                         binding.txtGame.text = "Противник выбрал Ножницы\nПобеда!"
                         binding.txtGame.setBackgroundColor(Color.GREEN)
                     }
                     3 -> {
                         binding.txtGame.text = "Противник выбрал Бумага\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                     4 -> {
                         binding.txtGame.text = "Противник выбрал Ящерица\nПоражение!"
                         binding.txtGame.setBackgroundColor(Color.RED)
                     }
                     5 -> {
                         binding.txtGame.text = "Противник выбрал Спок\nНичья!"
                         binding.txtGame.setBackgroundColor(Color.YELLOW)
                     }
                 }
             }
         }
     }

     fun btnGameClick(view: View) {
         super.onResume()

         binding.btnGame.isEnabled = false
         binding.btnGame.setBackgroundColor(Color.argb(255, 255, 0,0))
         binding.txtGame.setBackgroundColor(Color.argb(255, 255, 255,255))
         btnEnabled(true)

         binding.txtGame.text = "Противник выбрал предмет"

     }
}